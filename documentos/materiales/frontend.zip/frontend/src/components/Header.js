import React, { Component } from 'react'
import AppBar from 'material-ui/AppBar'
import Toolbar from 'material-ui/Toolbar'
import Typography from 'material-ui/Typography'
import Button from 'material-ui/Button'
import { Link } from 'react-router-dom'

class Header extends Component {

  render() {
    const s = {
      marginLeft:'60px'
    }
    
    return (
      <div>
        <AppBar position="static" color="default">
          <Toolbar>
            <Typography type="title" color="inherit">
              Restaurantes
            </Typography>
            <div style={s}>
               <Link to='/listar/granada'>
                  <Button raised color="primary">LISTAR &nbsp; <b>GRANÁ</b></Button>
               </Link>
            </div>
            <div style={s}>
               <Link to='/listar/italian'>
                  <Button raised color="primary">LISTAR &nbsp; <b>ITALIAN</b></Button>
               </Link>
            </div>
          </Toolbar>
        </AppBar>
      </div>
    );
  }
}

export default Header
