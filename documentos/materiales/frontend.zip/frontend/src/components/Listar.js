import React, { Component } from 'react'
import Paper from 'material-ui/Paper';
import Typography from 'material-ui/Typography'
import Table, { TableBody, TableCell, TableHead, TableRow } from 'material-ui/Table'

class Listar extends Component {

  // Primero se ejecuta:
  constructor() {
    super()
    this.state = {
     restaurantes: [],
    }
  }

  // y justo antes del render
  componentWillMount() {

    if (this.props.match.params.que === 'italian') {
    fetch('http://localhost:8000/r/api_italian/').then(
              res => res.json()).then(
                  data => {
                    console.log(data)
                    this.setState ({restaurantes:data})
                  })
   }
  }

  // y por último
  render() {

    var lista_restaurantes = this.state.restaurantes

    if (this.props.match.params.que === 'granada'){
       lista_restaurantes = [
         {name:'Casa Juan', cuisine:'granaína'},
         {name:'Casa Pepe', cuisine:'de Graná'}
      ]
    }

    const p = {
      paddingTop:'40px',
      paddingLeft:'200px',
      paddingRight:'200px'
    }

    return (
      <div>
         <Paper elevation={4} style={p}>
       <Typography type="title" color="inherit">
         Listando &nbsp; <b> {this.props.match.params.que} </b>
      </Typography>

      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Name</TableCell>
            <TableCell>Cuisine</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {lista_restaurantes.map(n => {
            return (
              <TableRow>
                <TableCell>{n.name}</TableCell>
                <TableCell>{n.cuisine}</TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>

         </Paper>
      </div>
    )
  }
}

export default Listar
