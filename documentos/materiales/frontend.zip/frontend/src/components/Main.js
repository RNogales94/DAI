import React, { Component } from 'react'
import { Switch, Route } from 'react-router-dom'
import Listar from './Listar'

class Main extends Component {
  render() {
    return (
      <Switch>
        <Route path="/listar/:que" component={Listar}/>
      </Switch>
    );
  }
}

export default Main
